package GUI;

public class TestMain {

	public static void main(String[] args) {

		MainMenu testMainMenu = new MainMenu();
	}
}
