package ejb;

import javax.ejb.Remote;

@Remote
public interface AppointmentDataServiceRemote extends AppointmentDataServiceLogic{
}
