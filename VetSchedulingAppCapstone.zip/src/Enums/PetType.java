package Enums;

public enum PetType {
	Cat,
	Dog,
	Exotic

}