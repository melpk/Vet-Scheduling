package Enums;

public enum AppointmentType {
	WellnessExam,
	Vaccination,
	RabiesShot,
	Surgery
}