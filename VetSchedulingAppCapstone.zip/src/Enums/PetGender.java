package Enums;

public enum PetGender {
	Male,
	Female,
	Unknown

}