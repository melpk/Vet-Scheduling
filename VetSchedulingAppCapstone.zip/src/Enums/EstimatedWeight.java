package Enums;

public enum EstimatedWeight {
	LessThanFifty,
	FiftyToOneHundred,
	OverOneHundred

}
